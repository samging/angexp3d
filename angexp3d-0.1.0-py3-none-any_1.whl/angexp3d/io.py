"""Reading 3D coordinates from arrays, text and files."""
from __future__ import annotations

import os
import re

import numpy as np

MIN_POINTS = 10


def as_points(arr, min_points: int = MIN_POINTS) -> np.ndarray:
    """Validate and clean an (n, 3) coordinate array.

    Rows that contain non-finite values (NaN / inf) are dropped.
    """
    arr = np.asarray(arr, dtype=float)
    if arr.ndim != 2 or arr.shape[1] != 3:
        raise ValueError(f"expected an (n, 3) array of x, y, z coordinates, got shape {arr.shape}")
    arr = arr[np.isfinite(arr).all(axis=1)]
    if len(arr) < min_points:
        raise ValueError(f"need at least {min_points} valid points, got {len(arr)}")
    return arr


def _parse_text(text: str) -> np.ndarray:
    """Lines of 'x y z' / 'x,y,z' / 'x;y;z'. Header and comment lines are skipped,
    extra columns are ignored."""
    rows = []
    for line in text.splitlines():
        parts = [q for q in re.split(r"[,;\s]+", line.strip()) if q]
        if len(parts) < 3:
            continue
        try:
            rows.append([float(q) for q in parts[:3]])    # only x, y, z must be numeric
        except ValueError:
            continue                                      # header or comment line
    return np.array(rows, dtype=float)


def _parse_obj(text: str) -> np.ndarray:
    rows = []
    for line in text.splitlines():
        if line.startswith("v "):
            rows.append([float(q) for q in line.split()[1:4]])
    return np.array(rows, dtype=float)


def _parse_ply(text: str) -> np.ndarray:
    """ASCII PLY only: the first three properties of every vertex are read as x, y, z."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "ply":
        raise ValueError("not a PLY file")
    n_vertex, end = None, None
    for i, line in enumerate(lines):
        tok = line.split()
        if line.startswith("format") and "ascii" not in line:
            raise ValueError("only ASCII PLY files are supported (found a binary PLY)")
        if tok[:2] == ["element", "vertex"]:
            n_vertex = int(tok[2])
        if line.strip() == "end_header":
            end = i
            break
    if n_vertex is None or end is None:
        raise ValueError("malformed PLY header")
    rows = [[float(q) for q in ln.split()[:3]] for ln in lines[end + 1:end + 1 + n_vertex]]
    return np.array(rows, dtype=float)


def load_points(src, min_points: int = MIN_POINTS) -> np.ndarray:
    """Return an (n, 3) float array from an array, a list, a text block or a file path.

    Supported files: ``.npy``, ``.obj`` (vertex lines), ASCII ``.ply``, and any text
    file with one point per line (``.csv``, ``.txt``, ``.xyz`` ...; comma, semicolon,
    space or tab separated; a header line is ignored).
    """
    if isinstance(src, (str, os.PathLike)):
        src = os.fspath(src)
        if os.path.exists(src):
            ext = os.path.splitext(src)[1].lower()
            if ext == ".npy":
                return as_points(np.load(src), min_points)
            with open(src, encoding="utf-8", errors="ignore") as fh:
                text = fh.read()
            if ext == ".obj":
                arr = _parse_obj(text)
            elif ext == ".ply":
                arr = _parse_ply(text)
            else:
                arr = _parse_text(text)
        elif "\n" in src or "," in src or ";" in src:
            arr = _parse_text(src)                      # pasted text
        else:
            raise FileNotFoundError(f"no such file: {src!r}")
        return as_points(arr, min_points)
    return as_points(src, min_points)
