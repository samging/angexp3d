"""Command line interface:  angexp3d mesh.obj --auto --plot out.png"""
from __future__ import annotations

import argparse
import sys

from . import __version__
from .analysis import run
from .core import MODES
from .shapes import SHAPES


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="angexp3d",
        description="Rotate a 3D point cloud, keep (x', depth), regenerate y' from x' with a "
                    "power law (+ sine) and report how well the shape is reconstructed.")
    p.add_argument("input", nargs="?",
                   help="mesh file (.obj, ASCII .ply, .csv, .txt, .xyz, .npy), or '-' for text on stdin")
    p.add_argument("--demo", choices=sorted(SHAPES), help="use a built-in test shape instead of a file")
    p.add_argument("--mode", choices=MODES, default="hybrid", help="fitting model (default: hybrid)")
    g = p.add_mutually_exclusive_group()
    g.add_argument("--angles", nargs=2, type=float, metavar=("TX", "TY"), default=[30.0, 45.0],
                   help="rotation angles in degrees about x and y (default: 30 45)")
    g.add_argument("--auto", action="store_true", help="search the best rotation angles (0-90 deg, step 15)")
    p.add_argument("--plot", metavar="PNG", help="save the 3-panel plot to this image file")
    p.add_argument("--show", action="store_true", help="open the plot in a window")
    p.add_argument("--save-reconstruction", metavar="CSV", help="write the reconstructed x,y,z to a CSV")
    p.add_argument("--save-compressed", metavar="NPZ", help="write the compressed representation to an .npz")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.demo:
        src, name = SHAPES[args.demo](), f"demo: {args.demo}"
    elif args.input == "-":
        src, name = sys.stdin.read(), "stdin"
    elif args.input:
        src, name = args.input, args.input
    else:
        build_parser().error("give a mesh file, '-' for stdin, or --demo NAME")
    try:
        run(src, name=name, mode=args.mode, angles="auto" if args.auto else tuple(args.angles),
            show=args.show, save_plot=args.plot, save_to=args.save_reconstruction,
            save_compressed=args.save_compressed)
    except (ValueError, OSError) as exc:
        print(f"angexp3d: error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
