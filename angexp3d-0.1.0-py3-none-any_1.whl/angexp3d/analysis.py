"""Evaluation: reconstruction error, storage ratios and a PCA baseline."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .core import Compressed, Transformer3D
from .io import load_points


def pca_rank2(points) -> tuple[np.ndarray, float]:
    """Baseline with the same storage layout: keep 2 principal coordinates per point.

    Returns (reconstruction, MSE).
    """
    points = np.asarray(points, dtype=float)
    mu = points.mean(axis=0)
    _, _, Vt = np.linalg.svd(points - mu, full_matrices=False)
    coeff = (points - mu) @ Vt[:2].T
    rec = coeff @ Vt[:2] + mu
    return rec, float(np.mean((points - rec) ** 2))


@dataclass
class Result:
    points: np.ndarray
    reconstruction: np.ndarray
    compressed: Compressed
    transformer: Transformer3D
    mse: float              # reconstruction MSE over all 3n coordinates (= fit_mse / 3)
    fit_mse: float          # MSE of the regenerated column y' only
    r2_y: float             # 1 - fit_mse / Var(y'); 1 = perfect, 0 = no better than a constant
    dist_pct: float         # mean point error as % of the bounding-box diagonal
    printed_ratio: float    # ratio when only x' and the model scalars are counted (misleading)
    real_ratio: float       # ratio when the depth column is counted as well
    pca_mse: float          # rank-2 PCA baseline with the same storage layout

    @property
    def n(self) -> int:
        return len(self.points)

    @property
    def beats_pca(self) -> bool:
        return self.mse < self.pca_mse

    def report(self, name: str = "points") -> str:
        t, c = self.transformer, self.compressed
        lines = [
            f"{name}: {self.n} points, mode = {c.mode}, angles = ({c.theta_x_deg:g}, {c.theta_y_deg:g})",
            f"  driver axis              : {c.driver_axis}",
            f"  p+1                      : {c.params[1]:.4f}   (a = {c.params[0]:.4f})",
        ]
        if c.mode == "hybrid":
            lines.append(f"  A, omega, phi            : {c.params[2]:.4f}, {c.params[3]:.4f}, {c.params[4]:.4f}")
        lines += [
            f"  fit MSE of y'            : {self.fit_mse:.5f}",
            f"  R2 of regenerated y'     : {self.r2_y:.3f}   (1 = perfect, 0 = no better than a constant)",
            f"  reconstruction MSE       : {self.mse:.5f}   (= fit MSE / 3)",
            f"  mean point error         : {self.dist_pct:.1f}% of the shape's size",
            f"  storage ratio            : {self.real_ratio:.3f}x real  "
            f"({self.printed_ratio:.2f}x if the depth were not counted)",
            f"  PCA rank-2 baseline MSE  : {self.pca_mse:.5f}",
        ]
        if self.pca_mse <= self.mse:
            lines.append("  -> PCA with the same storage reconstructs this shape at least as well.")
        else:
            lines.append("  -> better than the PCA baseline on this shape.")
        if self.r2_y < 0.5:
            lines.append("  -> low R2: y' is not a good function of x' for this shape, "
                         "expect a visibly distorted result.")
        return "\n".join(lines)


def evaluate(points, mode: str = "hybrid", theta_x_deg: float = 30.0,
             theta_y_deg: float = 45.0) -> Result:
    """Compress, reconstruct (with the stored depth) and measure."""
    points = load_points(points)
    t = Transformer3D(mode, theta_x_deg, theta_y_deg)
    comp = t.compress(points)
    rec = comp.decompress()
    err = t.axis_errors[t.driver_axis]
    diag = float(np.linalg.norm(points.max(0) - points.min(0)))
    dist = np.linalg.norm(points - rec, axis=1)
    raw = points.nbytes
    return Result(
        points=points, reconstruction=rec, compressed=comp, transformer=t,
        mse=float(np.mean((points - rec) ** 2)),
        fit_mse=err["mse"],
        r2_y=1.0 - err["mse"] / err["y_var"] if err["y_var"] > 1e-12 else 1.0,
        dist_pct=float(dist.mean()) / diag * 100.0 if diag > 0 else 0.0,
        printed_ratio=raw / comp.nbytes_without_depth,
        real_ratio=raw / comp.nbytes,
        pca_mse=pca_rank2(points)[1],
    )


def best_angles(points, mode: str = "hybrid", step: float = 15.0) -> tuple[float, float]:
    """Grid search over theta_x, theta_y in [0, 90] degrees for the lowest reconstruction MSE."""
    points = load_points(points)
    grid = np.arange(0.0, 90.0 + 1e-9, step)
    best = min((evaluate(points, mode, ax, ay).mse, float(ax), float(ay)) for ax in grid for ay in grid)
    return best[1], best[2]


def run(src, name: str = "points", mode: str = "hybrid", angles=(30.0, 45.0),
        plot: bool = False, show: bool = False, save_plot=None, save_to=None,
        save_compressed=None, verbose: bool = True) -> Result:
    """Load, fit, reconstruct, report (and optionally plot / save) in one call.

    ``angles`` is ``(theta_x_deg, theta_y_deg)`` or ``"auto"`` for a grid search.
    ``save_to`` writes the reconstructed coordinates to a CSV, ``save_compressed`` the
    :class:`Compressed` object to an ``.npz`` file.
    """
    points = load_points(src)
    if isinstance(angles, str):
        if angles != "auto":
            raise ValueError("angles must be (theta_x_deg, theta_y_deg) or 'auto'")
        angles = best_angles(points, mode)
        if verbose:
            print(f"auto angles -> theta_x = {angles[0]:.0f} deg, theta_y = {angles[1]:.0f} deg")
    result = evaluate(points, mode, *angles)
    if verbose:
        print(result.report(name))
    if save_to:
        np.savetxt(save_to, result.reconstruction, delimiter=",", header="x,y,z", comments="")
        if verbose:
            print(f"  reconstructed coordinates saved to {save_to}")
    if save_compressed:
        result.compressed.save(save_compressed)
        if verbose:
            print(f"  compressed representation saved to {save_compressed}")
    if plot or show or save_plot:
        from .plotting import plot_result
        plot_result(result, name=name, show=show, save=save_plot)
    return result
