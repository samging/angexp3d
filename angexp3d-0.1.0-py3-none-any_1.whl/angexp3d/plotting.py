"""Original / regenerated curve / reconstruction plot (needs matplotlib)."""
from __future__ import annotations

import numpy as np


def plot_result(result, name: str = "points", show: bool = False, save=None):
    """Three panels: original cloud, the 2D plane with the regenerated curve y' = f(x'),
    and the reconstruction coloured by point error. Returns the matplotlib Figure."""
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:  # pragma: no cover
        raise ImportError("plotting needs matplotlib: pip install 'angexp3d[plot]'") from exc

    points, rec, c = result.points, result.reconstruction, result.compressed
    d = c.driver_axis
    rot2 = (points @ result.transformer.R.T)[:, :2]
    x_true, y_true = rot2[:, d], rot2[:, 1 - d]
    y_hat = c.regenerated_column()
    err = np.linalg.norm(points - rec, axis=1)

    lo = np.minimum(points.min(0), rec.min(0))
    hi = np.maximum(points.max(0), rec.max(0))
    ext = np.maximum(hi - lo, 0.02 * max(float((hi - lo).max()), 1e-12))

    fig = plt.figure(figsize=(17, 4.9))
    gs = fig.add_gridspec(1, 4, width_ratios=[1, 1, 1, 0.04], wspace=0.28)

    ax1 = fig.add_subplot(gs[0], projection="3d")
    ax1.scatter(*points.T, c=points[:, 2], cmap="viridis", s=6)
    ax1.set_title("Original")

    ax2 = fig.add_subplot(gs[1])
    ax2.scatter(x_true, y_true, s=5, color="0.65", label="true y'")
    order = np.argsort(c.x)
    ax2.plot(c.x[order], y_hat[order], color="crimson", lw=2, label="regenerated y' = f(x')")
    ax2.set_xlabel("stored x'")
    ax2.set_ylabel("y'")
    extra = f",  A = {c.params[2]:.3f}" if c.mode == "hybrid" else ""
    ax2.set_title(f"driver axis {d}:  p+1 = {c.params[1]:.3f}{extra}\nR²(y') = {result.r2_y:.2f}")
    ax2.legend(loc="best")
    ax2.grid(alpha=0.3)

    ax3 = fig.add_subplot(gs[2], projection="3d")
    sc = ax3.scatter(*rec.T, c=err, cmap="magma_r", s=6)
    fig.colorbar(sc, cax=fig.add_subplot(gs[3]), label="point error")
    ax3.set_title(f"Reconstruction  (mean error {result.dist_pct:.1f}% of size)")

    for ax in (ax1, ax3):
        ax.set_xlim(lo[0], lo[0] + ext[0])
        ax.set_ylim(lo[1], lo[1] + ext[1])
        ax.set_zlim(lo[2], lo[2] + ext[2])
        # a tuple: matplotlib edits a passed ndarray in place, which corrupts the other axes
        ax.set_box_aspect(tuple(float(v) for v in ext), zoom=0.85)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")

    fig.suptitle(f"{name}  -  mode: {c.mode}", fontweight="bold", y=1.06)
    if save:
        fig.savefig(save, dpi=130, bbox_inches="tight")
    if show:
        plt.show()
    return fig
