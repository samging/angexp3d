"""Test shapes taken from the original notebook (all return an (n, 3) array)."""
from __future__ import annotations

import numpy as np


def egg(num_u: int = 30, num_v: int = 30) -> np.ndarray:
    u = np.linspace(0, np.pi, num_u)
    v = np.linspace(0, 2 * np.pi, num_v)
    U, V = np.meshgrid(u, v)
    a, b, k = 1.0, 1.5, 0.2
    r = a * np.sin(U) * (1 + k * np.cos(U))
    return np.column_stack([(r * np.cos(V)).ravel(), (r * np.sin(V)).ravel(), (b * np.cos(U)).ravel()])


def hugelschaffer_egg(a: float = 1.0, b: float = 0.7, w: float = 0.2,
                      num_u: int = 30, num_v: int = 30) -> np.ndarray:
    u = np.linspace(-np.pi / 2, np.pi / 2, num_u)
    v = np.linspace(0, 2 * np.pi, num_v)
    U, V = np.meshgrid(u, v)
    X = a * np.cos(U)
    Y = b * (1.0 - w * np.sin(U)) * np.sin(U) * np.cos(V)
    Z = b * (1.0 - w * np.sin(U)) * np.sin(U) * np.sin(V)
    return np.column_stack([X.ravel(), Y.ravel(), Z.ravel()])


def square(side: float = 2.0, k: int = 30) -> np.ndarray:
    x = np.linspace(-side / 2, side / 2, k)
    X, Y = np.meshgrid(x, x)
    return np.column_stack([X.ravel(), Y.ravel(), np.zeros(k * k)])


def cube(side: float = 2.0, num_samples: int = 1000, seed: int = 42) -> np.ndarray:
    rng = np.random.RandomState(seed)       # same stream as the notebook's np.random.seed(42)
    pts, c = [], side / 2
    for _ in range(num_samples // 6):
        u, v = rng.uniform(-side / 2, side / 2, 2)
        pts += [[c, u, v], [-c, u, v], [u, c, v], [u, -c, v], [u, v, c], [u, v, -c]]
    return np.array(pts)


def sphere(radius: float = 1.0, num_points: int = 1000) -> np.ndarray:
    i = np.arange(0, num_points, dtype=float) + 0.5
    phi = np.arccos(1 - 2 * i / num_points)
    th = np.pi * (1 + 5 ** 0.5) * i
    return np.column_stack([radius * np.sin(phi) * np.cos(th),
                            radius * np.sin(phi) * np.sin(th), radius * np.cos(phi)])


def plane(side: float = 2.0, k: int = 30) -> np.ndarray:
    x = np.linspace(-side / 2, side / 2, k)
    X, Y = np.meshgrid(x, x)
    return np.column_stack([X.ravel(), Y.ravel(), (0.5 * X - 0.8 * Y + 1.2).ravel()])


def paraboloid(nr: int = 30, na: int = 30) -> np.ndarray:
    r = np.linspace(0.1, 2.0, nr)
    th = np.linspace(0, 2 * np.pi, na)
    Rg, Tg = np.meshgrid(r, th)
    X, Y = Rg * np.cos(Tg), Rg * np.sin(Tg)
    return np.column_stack([X.ravel(), Y.ravel(), (0.5 * X ** 2 + 0.3 * Y ** 2).ravel()])


def wavy_sheet(k: int = 30) -> np.ndarray:
    g = np.linspace(-2, 2, k)
    GX, GY = np.meshgrid(g, g)
    return np.column_stack([GX.ravel(), GY.ravel(), (np.sin(GX) * np.cos(GY)).ravel()])


SHAPES = {
    "egg": egg,
    "hugelschaffer": hugelschaffer_egg,
    "square": square,
    "cube": cube,
    "sphere": sphere,
    "plane": plane,
    "paraboloid": paraboloid,
    "wavy": wavy_sheet,
}
