"""angexp3d - angle-exponent-Fourier transformer for 3D point clouds and meshes.

Quick start::

    import angexp3d
    result = angexp3d.run("mesh.obj", angles="auto", save_plot="out.png")
    result.reconstruction        # (n, 3) reconstructed coordinates
    result.compressed.save("mesh.npz")
"""
from . import shapes
from .analysis import Result, best_angles, evaluate, pca_rank2, run
from .core import MODES, Compressed, Transformer3D, rotation_matrix
from .io import as_points, load_points

__version__ = "0.1.0"

# name used in the original notebook
AngleExponentFourier3D = Transformer3D

__all__ = [
    "AngleExponentFourier3D", "Compressed", "MODES", "Result", "Transformer3D", "as_points",
    "best_angles", "evaluate", "load_points", "pca_rank2", "rotation_matrix", "run", "shapes",
]
